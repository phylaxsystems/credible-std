// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Assertion} from "credible-std/Assertion.sol";
import {PhEvm} from "credible-std/PhEvm.sol";

/// @notice Minimal EVault surface needed by the assertions below.
/// @dev The selectors match EVK's IEVault modules. Keep this local so the
///      assertion package does not need the full EVK tree at runtime.
interface IEVaultLike {
    // ERC20 / share token
    function totalSupply() external view returns (uint256);
    function balanceOf(address account) external view returns (uint256);
    function transfer(address to, uint256 amount) external returns (bool);
    function transferFrom(address from, address to, uint256 amount) external returns (bool);
    function transferFromMax(address from, address to) external returns (bool);

    // ERC4626 / vault accounting
    function asset() external view returns (address);
    function totalAssets() external view returns (uint256);
    function deposit(uint256 amount, address receiver) external returns (uint256);
    function mint(uint256 amount, address receiver) external returns (uint256);
    function withdraw(uint256 amount, address receiver, address owner) external returns (uint256);
    function redeem(uint256 amount, address receiver, address owner) external returns (uint256);
    function skim(uint256 amount, address receiver) external returns (uint256);

    // Borrowing
    function cash() external view returns (uint256);
    function totalBorrows() external view returns (uint256);
    function debtOf(address account) external view returns (uint256);
    function debtOfExact(address account) external view returns (uint256);
    function dToken() external view returns (address);
    function borrow(uint256 amount, address receiver) external returns (uint256);
    function repay(uint256 amount, address receiver) external returns (uint256);
    function repayWithShares(uint256 amount, address receiver) external returns (uint256 shares, uint256 debt);
    function pullDebt(uint256 amount, address from) external;
    function flashLoan(uint256 amount, bytes calldata data) external;
    function touch() external;

    // Liquidation
    function checkLiquidation(address liquidator, address violator, address collateral)
        external
        view
        returns (uint256 maxRepay, uint256 maxYield);
    function liquidate(address violator, address collateral, uint256 repayAssets, uint256 minYieldBalance) external;
}

/// @notice Shared helpers for factory-scoped EVault assertions.
/// @dev These assertions are meant to be attached to every EVault clone/proxy
///      discovered out of band by the v2 factory integration. At runtime the
///      assertion adopter is the concrete EVault instance.
abstract contract EulerV2Base is Assertion {
    // EVK ConversionHelpers.conversionTotals() virtual deposit.
    uint256 internal constant VIRTUAL_DEPOSIT_AMOUNT = 1e6;

    // Storage layout in EVK Storage.sol:
    //   slot 0: initialized
    //   slot 1: snapshot
    //   slot 2: VaultStorage struct base
    //   VaultStorage.users is field 11 inside the struct
    // Therefore users mapping base slot = 2 + 11 = 13.
    bytes32 internal constant USERS_MAPPING_SLOT = bytes32(uint256(13));

    bytes32 internal constant TRANSFER_SIG = keccak256("Transfer(address,address,uint256)");
    bytes32 internal constant DEBT_SOCIALIZED_SIG = keccak256("DebtSocialized(address,uint256)");
    bytes32 internal constant LIQUIDATE_SIG = keccak256("Liquidate(address,address,address,uint256,uint256)");

    uint256 internal constant SHARES_MASK = 0x000000000000000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFFFFFF;
    uint256 internal constant OWED_MASK = 0x7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF0000000000000000000000000000;
    uint256 internal constant OWED_OFFSET = 112;

    function _vault() internal view returns (address) {
        return ph.getAssertionAdopter();
    }

    function _totalAssetsAt(address vault, PhEvm.ForkId memory fork) internal view returns (uint256) {
        return _readUintAt(vault, abi.encodeCall(IEVaultLike.totalAssets, ()), fork);
    }

    function _totalSupplyAt(address vault, PhEvm.ForkId memory fork) internal view returns (uint256) {
        return _readUintAt(vault, abi.encodeCall(IEVaultLike.totalSupply, ()), fork);
    }

    function _debtOfAt(address vault, address account, PhEvm.ForkId memory fork) internal view returns (uint256) {
        return _readUintAt(vault, abi.encodeCall(IEVaultLike.debtOf, (account)), fork);
    }

    function _dTokenAt(address vault, PhEvm.ForkId memory fork) internal view returns (address) {
        return _readAddressAt(vault, abi.encodeCall(IEVaultLike.dToken, ()), fork);
    }

    function _topicAddress(bytes32 topic) internal pure returns (address) {
        return address(uint160(uint256(topic)));
    }

    function _stripSelector(bytes memory input) internal pure returns (bytes memory args) {
        require(input.length >= 4, "EulerV2: short calldata");
        args = new bytes(input.length - 4);
        for (uint256 i; i < args.length; ++i) args[i] = input[i + 4];
    }

    function _signedDelta(uint256 beforeValue, uint256 afterValue) internal pure returns (int256) {
        if (afterValue >= beforeValue) {
            uint256 delta = afterValue - beforeValue;
            require(delta <= uint256(type(int256).max), "EulerV2: delta too large");
            return int256(delta);
        }

        uint256 negativeDelta = beforeValue - afterValue;
        require(negativeDelta <= uint256(type(int256).max), "EulerV2: delta too large");
        return -int256(negativeDelta);
    }

    function _addSigned(int256 accumulator, uint256 value, bool positive) internal pure returns (int256) {
        require(value <= uint256(type(int256).max), "EulerV2: amount too large");
        return positive ? accumulator + int256(value) : accumulator - int256(value);
    }

    function _netErc20TransferDelta(address token, address account, PhEvm.ForkId memory fork)
        internal
        view
        returns (int256 net)
    {
        PhEvm.Erc20TransferData[] memory transfers = ph.getErc20Transfers(token, fork);

        for (uint256 i; i < transfers.length; ++i) {
            if (transfers[i].to == account) net = _addSigned(net, transfers[i].value, true);
            if (transfers[i].from == account) net = _addSigned(net, transfers[i].value, false);
        }
    }

    function _eventAmount(bytes memory data) internal pure returns (uint256 amount) {
        require(data.length >= 32, "EulerV2: malformed event data");
        amount = abi.decode(data, (uint256));
    }

    function _rawShares(bytes32 packedUserData) internal pure returns (uint256) {
        return uint256(packedUserData) & SHARES_MASK;
    }

    function _rawOwed(bytes32 packedUserData) internal pure returns (uint256) {
        return (uint256(packedUserData) & OWED_MASK) >> OWED_OFFSET;
    }

    function _keyToAddress(bytes memory key) internal pure returns (address account) {
        require(key.length == 32, "EulerV2: non-address mapping key");
        account = abi.decode(key, (address));
    }
}

/// @notice V2 mapping-trace assertion: every end-of-transaction user share/debt
///         delta in EVault storage must be observable as a matching share-token or
///         DToken Transfer delta.
///
/// Why this is a v2-only killer assertion:
/// - Factories let the same assertion bind directly to every EVault instance.
/// - `changedMappingKeys` recovers the modified `vaultStorage.users[account]`
///   keys without decoding EVC batches, nested `call`, `controlCollateral`, or
///   arbitrary routers.
/// - ERC20 transfer introspection removes manual log parsing.
abstract contract EulerUserStorageEventAccountingMixin is EulerV2Base {
    function _registerUserStorageEventAccounting() internal view {
        registerTxEndTrigger(this.assertUserStorageDeltasMatchTokenEvents.selector);
    }

    function assertUserStorageDeltasMatchTokenEvents() external view {
        address vault = _vault();
        address dToken = _dTokenAt(vault, _postTx());
        bytes[] memory keys = ph.changedMappingKeys(vault, USERS_MAPPING_SLOT);

        for (uint256 i; i < keys.length; ++i) {
            _assertChangedUserDeltas(vault, dToken, keys[i]);
        }
    }

    function _assertChangedUserDeltas(address vault, address dToken, bytes memory key) internal view {
        address account = _keyToAddress(key);

        (bytes32 prePacked, bytes32 postPacked, bool dataChanged) =
            ph.mappingValueDiff(vault, USERS_MAPPING_SLOT, key, 0);
        (bytes32 preAcc, bytes32 postAcc, bool accumulatorChanged) =
            ph.mappingValueDiff(vault, USERS_MAPPING_SLOT, key, 1);

        if (!dataChanged && !accumulatorChanged) return;

        _assertShareDelta(vault, account, prePacked, postPacked);
        _assertDebtDelta(vault, dToken, account, prePacked, postPacked, preAcc, postAcc, accumulatorChanged);
    }

    function _assertShareDelta(address vault, address account, bytes32 prePacked, bytes32 postPacked) internal view {
        uint256 preRawShares = _rawShares(prePacked);
        uint256 postRawShares = _rawShares(postPacked);
        if (preRawShares == postRawShares) return;

        uint256 preBalance = _readBalanceAt(vault, account, _preTx());
        uint256 postBalance = _readBalanceAt(vault, account, _postTx());
        require(postBalance == postRawShares, "EulerV2: balanceOf != packed shares");

        int256 storageDelta = _signedDelta(preBalance, postBalance);
        int256 eventDelta = _netErc20TransferDelta(vault, account, _postTx());
        require(storageDelta == eventDelta, "EulerV2: share storage delta lacks Transfer");
    }

    function _assertDebtDelta(
        address vault,
        address dToken,
        address account,
        bytes32 prePacked,
        bytes32 postPacked,
        bytes32 preAcc,
        bytes32 postAcc,
        bool accumulatorChanged
    ) internal view {
        uint256 preRawOwed = _rawOwed(prePacked);
        uint256 postRawOwed = _rawOwed(postPacked);
        if (preRawOwed == postRawOwed && !accumulatorChanged) return;
        if (preRawOwed == postRawOwed && preAcc == postAcc) return;

        uint256 preDebt = _debtOfAt(vault, account, _preTx());
        uint256 postDebt = _debtOfAt(vault, account, _postTx());
        int256 storageDelta = _signedDelta(preDebt, postDebt);
        int256 eventDelta = _netErc20TransferDelta(dToken, account, _postTx());
        require(storageDelta == eventDelta, "EulerV2: debt delta lacks DToken Transfer");
    }
}

/// @notice V2 call-scoped assertion: an EVault's virtual-deposit share price may
///         not decrease during any individual mutating call unless that same call
///         socializes debt, and any decrease must be bounded by the socialized debt.
///
/// This catches a bad call inside an EVC batch even if a later call repairs the
/// transaction-level pre/post price before V1 could observe it.
abstract contract EulerPerCallSharePriceMixin is EulerV2Base {
    uint256 public immutable sharePriceToleranceBps;

    constructor(uint256 toleranceBps_) {
        sharePriceToleranceBps = toleranceBps_;
    }

    function _registerPerCallSharePrice() internal view {
        registerFnCallTrigger(this.assertPerCallSharePriceDropOnlyFromSocialization.selector, IEVaultLike.deposit.selector);
        registerFnCallTrigger(this.assertPerCallSharePriceDropOnlyFromSocialization.selector, IEVaultLike.mint.selector);
        registerFnCallTrigger(this.assertPerCallSharePriceDropOnlyFromSocialization.selector, IEVaultLike.withdraw.selector);
        registerFnCallTrigger(this.assertPerCallSharePriceDropOnlyFromSocialization.selector, IEVaultLike.redeem.selector);
        registerFnCallTrigger(this.assertPerCallSharePriceDropOnlyFromSocialization.selector, IEVaultLike.skim.selector);
        registerFnCallTrigger(this.assertPerCallSharePriceDropOnlyFromSocialization.selector, IEVaultLike.borrow.selector);
        registerFnCallTrigger(this.assertPerCallSharePriceDropOnlyFromSocialization.selector, IEVaultLike.repay.selector);
        registerFnCallTrigger(this.assertPerCallSharePriceDropOnlyFromSocialization.selector, IEVaultLike.repayWithShares.selector);
        registerFnCallTrigger(this.assertPerCallSharePriceDropOnlyFromSocialization.selector, IEVaultLike.pullDebt.selector);
        registerFnCallTrigger(this.assertPerCallSharePriceDropOnlyFromSocialization.selector, IEVaultLike.flashLoan.selector);
        registerFnCallTrigger(this.assertPerCallSharePriceDropOnlyFromSocialization.selector, IEVaultLike.touch.selector);
        registerFnCallTrigger(this.assertPerCallSharePriceDropOnlyFromSocialization.selector, IEVaultLike.liquidate.selector);
        registerFnCallTrigger(this.assertPerCallSharePriceDropOnlyFromSocialization.selector, IEVaultLike.transfer.selector);
        registerFnCallTrigger(this.assertPerCallSharePriceDropOnlyFromSocialization.selector, IEVaultLike.transferFrom.selector);
        registerFnCallTrigger(this.assertPerCallSharePriceDropOnlyFromSocialization.selector, IEVaultLike.transferFromMax.selector);
    }

    function assertPerCallSharePriceDropOnlyFromSocialization() external view {
        address vault = _vault();
        PhEvm.TriggerContext memory ctx = ph.context();
        PhEvm.ForkId memory beforeFork = _preCall(ctx.callStart);
        PhEvm.ForkId memory afterFork = _postCall(ctx.callEnd);

        uint256 preAssets = _totalAssetsAt(vault, beforeFork) + VIRTUAL_DEPOSIT_AMOUNT;
        uint256 preShares = _totalSupplyAt(vault, beforeFork) + VIRTUAL_DEPOSIT_AMOUNT;
        uint256 postAssets = _totalAssetsAt(vault, afterFork) + VIRTUAL_DEPOSIT_AMOUNT;
        uint256 postShares = _totalSupplyAt(vault, afterFork) + VIRTUAL_DEPOSIT_AMOUNT;

        bool noDrop = ph.ratioGe(postAssets, postShares, preAssets, preShares, sharePriceToleranceBps);
        if (noDrop) return;

        uint256 socialized = _socializedDebtInCall(vault, ctx.callStart);
        require(socialized != 0, "EulerV2: share price dropped without debt socialization");

        // If we add back the socialized debt, the call must not have caused any
        // unexplained share-price loss.
        require(
            ph.ratioGe(postAssets + socialized, postShares, preAssets, preShares, sharePriceToleranceBps),
            "EulerV2: share price drop exceeds socialized debt"
        );
    }

    function _socializedDebtInCall(address vault, uint256 callId) internal view returns (uint256 socialized) {
        PhEvm.LogQuery memory q = PhEvm.LogQuery({emitter: vault, signature: DEBT_SOCIALIZED_SIG});
        PhEvm.Log[] memory logs = ph.getLogsForCall(q, callId);

        for (uint256 i; i < logs.length; ++i) {
            socialized += _eventAmount(logs[i].data);
        }
    }
}

/// @notice V2 call-scoped assertion: every successful liquidation must stay
///         within the exact `checkLiquidation()` quote from immediately before
///         that liquidation call.
///
/// This is not expressible with V1's pre-tx/post-tx model because a batch can
/// modify the violator, collateral set, oracle state, or vault accounting before
/// the liquidation call and then clean up afterwards.
abstract contract EulerLiquidationQuoteMixin is EulerV2Base {
    struct LiquidationInput {
        address violator;
        address collateral;
        uint256 requestedRepay;
        uint256 minYieldBalance;
    }

    struct LiquidationEventData {
        bool found;
        address liquidator;
        address violator;
        address collateral;
        uint256 repayAssets;
        uint256 yieldBalance;
    }

    function _registerLiquidationQuote() internal view {
        registerFnCallTrigger(this.assertLiquidationMatchesPreCallQuote.selector, IEVaultLike.liquidate.selector);
    }

    function assertLiquidationMatchesPreCallQuote() external view {
        PhEvm.TriggerContext memory ctx = ph.context();
        _assertLiquidationCall(_vault(), ctx.callStart);
    }

    function _assertLiquidationCall(address vault, uint256 callId) internal view {
        LiquidationInput memory input = _liquidationInput(callId);
        LiquidationEventData memory eventData = _liquidateEventForCall(vault, callId);

        require(eventData.found, "EulerV2: missing Liquidate event");
        require(eventData.violator == input.violator, "EulerV2: Liquidate violator mismatch");
        require(eventData.collateral == input.collateral, "EulerV2: Liquidate collateral mismatch");

        _assertLiquidationWithinQuote(vault, callId, input, eventData);
    }

    function _liquidationInput(uint256 callId) internal view returns (LiquidationInput memory inputData) {
        bytes memory input = ph.callinputAt(callId);
        (inputData.violator, inputData.collateral, inputData.requestedRepay, inputData.minYieldBalance) =
            abi.decode(_stripSelector(input), (address, address, uint256, uint256));
    }

    function _assertLiquidationWithinQuote(
        address vault,
        uint256 callId,
        LiquidationInput memory inputData,
        LiquidationEventData memory eventData
    ) internal view {
        (uint256 maxRepay, uint256 maxYield) = abi.decode(
            _viewAt(
                vault,
                abi.encodeCall(IEVaultLike.checkLiquidation, (eventData.liquidator, inputData.violator, inputData.collateral)),
                _preCall(callId)
            ),
            (uint256, uint256)
        );

        require(eventData.repayAssets <= maxRepay, "EulerV2: liquidation repaid above pre-call quote");
        require(eventData.yieldBalance <= maxYield, "EulerV2: liquidation yielded above pre-call quote");
        require(eventData.yieldBalance >= inputData.minYieldBalance, "EulerV2: liquidation ignored min yield");

        if (inputData.requestedRepay != type(uint256).max) {
            require(eventData.repayAssets == inputData.requestedRepay, "EulerV2: liquidation repay != requested repay");
        }
    }

    function _liquidateEventForCall(address vault, uint256 callId)
        internal
        view
        returns (LiquidationEventData memory eventData)
    {
        PhEvm.LogQuery memory q = PhEvm.LogQuery({emitter: vault, signature: LIQUIDATE_SIG});
        PhEvm.Log[] memory logs = ph.getLogsForCall(q, callId);
        require(logs.length <= 1, "EulerV2: multiple Liquidate events in one call");
        if (logs.length == 0) return eventData;

        PhEvm.Log memory log = logs[0];
        require(log.topics.length >= 3, "EulerV2: malformed Liquidate topics");
        eventData.found = true;
        eventData.liquidator = _topicAddress(log.topics[1]);
        eventData.violator = _topicAddress(log.topics[2]);
        (eventData.collateral, eventData.repayAssets, eventData.yieldBalance) =
            abi.decode(log.data, (address, uint256, uint256));
    }
}
/// @notice V2 rolling-window outflow breaker. The executor tracks cumulative
///         underlying outflow over time; when the threshold is breached, this
///         smart breaker blocks risk-increasing outflow paths while allowing
///         stabilizing paths such as repay/deposit/touch.
///
/// For factory installs, pass the EVault asset from the out-of-band factory
/// indexer/config when creating the assertion for each vault.
abstract contract EulerSmartOutflowCircuitBreakerMixin is EulerV2Base {
    address public immutable outflowAsset;
    uint256 public immutable outflowThresholdBps;
    uint256 public immutable outflowWindowDuration;

    constructor(address asset_, uint256 thresholdBps_, uint256 windowDuration_) {
        outflowAsset = asset_;
        outflowThresholdBps = thresholdBps_;
        outflowWindowDuration = windowDuration_;
    }

    function _registerOutflowBreaker() internal view {
        watchCumulativeOutflow(
            outflowAsset,
            outflowThresholdBps,
            outflowWindowDuration,
            this.assertNoRiskIncreasingOutflowDuringBreaker.selector
        );
    }

    function assertNoRiskIncreasingOutflowDuringBreaker() external view {
        address vault = _vault();
        PhEvm.OutflowContext memory ctx = ph.outflowContext();
        require(ctx.token == outflowAsset, "EulerV2: wrong outflow token context");

        require(_matchingCalls(vault, IEVaultLike.withdraw.selector, 1).length == 0, "EulerV2: withdraw blocked");
        require(_matchingCalls(vault, IEVaultLike.redeem.selector, 1).length == 0, "EulerV2: redeem blocked");
        require(_matchingCalls(vault, IEVaultLike.borrow.selector, 1).length == 0, "EulerV2: borrow blocked");
        require(_matchingCalls(vault, IEVaultLike.flashLoan.selector, 1).length == 0, "EulerV2: flashLoan blocked");
        require(_matchingCalls(vault, IEVaultLike.skim.selector, 1).length == 0, "EulerV2: skim blocked");
    }
}

/// @notice Full bundle: attach to each factory-created EVault.
contract EulerVaultV2KillerAssertionBundle is
    EulerUserStorageEventAccountingMixin,
    EulerPerCallSharePriceMixin,
    EulerLiquidationQuoteMixin,
    EulerSmartOutflowCircuitBreakerMixin
{
    constructor(
        address asset_,
        uint256 sharePriceToleranceBps_,
        uint256 outflowThresholdBps_,
        uint256 outflowWindowDuration_
    )
        EulerPerCallSharePriceMixin(sharePriceToleranceBps_)
        EulerSmartOutflowCircuitBreakerMixin(asset_, outflowThresholdBps_, outflowWindowDuration_)
    {}

    function triggers() external view override {
        _registerUserStorageEventAccounting();
        _registerPerCallSharePrice();
        _registerLiquidationQuote();
        _registerOutflowBreaker();
    }
}

/// @notice Standalone variants for incremental rollout/backtesting.
contract EulerUserStorageEventAccountingAssertion is EulerUserStorageEventAccountingMixin {
    function triggers() external view override {
        _registerUserStorageEventAccounting();
    }
}

contract EulerPerCallSharePriceAssertion is EulerPerCallSharePriceMixin {
    constructor(uint256 sharePriceToleranceBps_) EulerPerCallSharePriceMixin(sharePriceToleranceBps_) {}

    function triggers() external view override {
        _registerPerCallSharePrice();
    }
}

contract EulerLiquidationQuoteAssertion is EulerLiquidationQuoteMixin {
    function triggers() external view override {
        _registerLiquidationQuote();
    }
}

contract EulerSmartOutflowCircuitBreakerAssertion is EulerSmartOutflowCircuitBreakerMixin {
    constructor(address asset_, uint256 thresholdBps_, uint256 windowDuration_)
        EulerSmartOutflowCircuitBreakerMixin(asset_, thresholdBps_, windowDuration_)
    {}

    function triggers() external view override {
        _registerOutflowBreaker();
    }
}
