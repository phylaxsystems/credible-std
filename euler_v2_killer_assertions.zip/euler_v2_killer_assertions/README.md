# Euler v2 killer assertions

This package is a draft set of v2 Credible assertions for Euler Vault Kit EVaults. It is intentionally focused on a few invariants that are either impossible or extremely awkward in the old v1 assertion style.

The old EVC assertions had to attach to broad EVC entry points such as `batch`, `call`, and `controlCollateral`, then manually unpack nested calldata and manually parse logs. These v2 assertions assume the factory integration attaches the assertion to each EVault instance out of band, so each assertion can read `ph.getAssertionAdopter()` as the concrete vault.

## Assertions

### 1. `EulerUserStorageEventAccountingAssertion`

Checks every modified `vaultStorage.users[account]` key at tx end. If the packed share balance changed, the account's `balanceOf` delta must equal the net EVault share-token `Transfer` delta. If the packed debt field or user debt accumulator changed, the account's `debtOf` delta must equal the net DToken `Transfer` delta.

Why it needs v2:

- Uses factory-scoped adoption to bind directly to each EVault.
- Uses `changedMappingKeys` and `mappingValueDiff` to discover touched users without decoding EVC batches or routers.
- Uses `getErc20Transfers` instead of manual log parsing.

Caveat: `USERS_MAPPING_SLOT` is set to `13` for the checked-in EVK layout: `initialized` at slot 0, `snapshot` at slot 1, and `vaultStorage.users` at slot 13 after the packed `VaultStorage` fields. Verify this against compiler storage layout in CI if EVK storage changes.

### 2. `EulerPerCallSharePriceAssertion`

Checks the virtual-deposit share price around every individual EVault mutating call:

```text
(totalAssets + 1e6) / (totalSupply + 1e6)
```

The ratio may not decrease within a call unless that same call emits `DebtSocialized`, and adding back the socialized amount must explain the full decrease.

Why it needs v2:

- Uses `TriggerContext`, `PreCall`, and `PostCall` to detect bad intermediate calls inside a larger transaction or EVC batch.
- Uses `getLogsForCall` so debt socialization must happen in the same call, not somewhere else in the transaction.
- V1's pre-tx/post-tx model could miss an intra-batch price drop repaired by a later call.

### 3. `EulerLiquidationQuoteAssertion`

For every successful `liquidate`, decodes the call input, reads the `Liquidate` event from that exact call, then calls `checkLiquidation(liquidator, violator, collateral)` at `PreCall`. It asserts the emitted repay/yield stay within the exact pre-call quote and that `minYieldBalance` is honored.

Why it needs v2:

- Uses `callinputAt` and `getLogsForCall` for precise call-local linkage.
- Uses `staticcallAt(..., PreCall(callId))` to quote liquidation at the state immediately before liquidation, not at tx start.
- V1 cannot express this accurately for EVC batches that alter account state before and after liquidation.

### 4. `EulerSmartOutflowCircuitBreakerAssertion`

Registers a cumulative outflow watcher for the EVault's underlying asset. When the rolling-window threshold is tripped, it blocks risk-increasing outflow paths: `withdraw`, `redeem`, `borrow`, `flashLoan`, and `skim`. Stabilizing calls such as `deposit`, `repay`, and `touch` remain allowed.

Why it needs v2:

- Uses `watchCumulativeOutflow`, a v2 rolling-window trigger unavailable in v1.
- The underlying asset is supplied by the out-of-band factory integration when deploying/attaching the assertion.

## Contracts

`src/EulerV2KillerAssertions.sol` includes:

- `EulerVaultV2KillerAssertionBundle`: all assertions bundled for a vault.
- Standalone rollout/backtesting variants:
  - `EulerUserStorageEventAccountingAssertion`
  - `EulerPerCallSharePriceAssertion`
  - `EulerLiquidationQuoteAssertion`
  - `EulerSmartOutflowCircuitBreakerAssertion`

## Compile check

The file was syntax-checked with the included `solc8.24` binary and the uploaded `credible-std-spark` sources:

```bash
/mnt/data/work_euler_assertions/ethereum-vault-connector-phylax-assertions/.github/executables/solc8.24 \
  credible-std/=/mnt/data/work_euler_assertions/credible-std-spark/src/ \
  --allow-paths /mnt/data/work_euler_assertions/credible-std-spark/src,/mnt/data/euler_v2_killer_assertions \
  --bin src/EulerV2KillerAssertions.sol
```
